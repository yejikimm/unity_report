using UnityEngine;
using UnityEditor;
using UnityEngine.TestTools;
using NUnit.Framework;
using System.Collections;



public class PurchasingEditorTest {

    [Test]
    public void PassingTest()
    {
        Assert.IsTrue(true);
    }
}